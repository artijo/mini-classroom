package com.javaweb.firstspringboot2023;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Firstspringboot2023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
