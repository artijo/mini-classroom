package com.javaweb.SpringbootLab9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootLab9Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootLab9Application.class, args);
	}

}
